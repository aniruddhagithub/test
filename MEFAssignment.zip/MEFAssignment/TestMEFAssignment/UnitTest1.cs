﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MEFAssignment;
using System.Collections.Generic;

namespace TestMEFAssignment
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestReaderClassType()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();

            Assert.AreEqual(service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "json").GetType(), typeof(MEFAssignment.JsonReader));
            Assert.AreEqual(service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "xml").GetType(), typeof(MEFAssignment.XmLReader));            
        }



        [TestMethod]
        public void TestReadAllServerForXML()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "xml");
            // var reader = service.GetReader(args[0], args[1]);
            List<string> expectedOutput = new List<string>();
            expectedOutput.Add("server1");
            expectedOutput.Add("server2");
            List<string> actualOutput = reader.ReadAllServer();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);
        }


        [TestMethod]
        public void TestReadAllServerForJson()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "json");


            List<string> expectedOutput = new List<string>();
            expectedOutput.Add("server1");
            expectedOutput.Add("server2");
            List<string> actualOutput = reader.ReadAllServer();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);
        }


        [TestMethod]
        public void TestReadAllEndPointsForJson()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "json");


            List<string> expectedOutput = new List<string>();
            expectedOutput.Add("api/getfiles");
            expectedOutput.Add("api/insertfiles");
            List<string> actualOutput = reader.ReadAllEndPoints();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);

            
        }

        [TestMethod]
        public void TestReadAllEndPointsForXml()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "xml");

            List<string> expectedOutput = new List<string>();
            expectedOutput.Add("api/getfiles");
            expectedOutput.Add("api/insertfiles");
            List<string> actualOutput = reader.ReadAllEndPoints();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);
        }



        [TestMethod]
        public void TestReadAllActiveEndPointsForXml()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "xml");

            List<string> expectedOutput = new List<string>();
            expectedOutput.Add("api/getfiles");            
            List<string> actualOutput = reader.ReadActiveEndPoints();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);

            
        }


        [TestMethod]
        public void TestReadAllActiveEndPointsForJson()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "json");


            List<string> expectedOutput = new List<string>();
            expectedOutput.Add("api/getfiles");
            List<string> actualOutput = reader.ReadActiveEndPoints();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);
        }




        [TestMethod]
        public void TestReadServersEndPointsInformationForXml()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "xml");


            List<EndPointInformation> expectedOutput = new List<EndPointInformation>();

            EndPointInformation epInfo1 = new EndPointInformation();
            epInfo1.Server = "server1";
            epInfo1.EndPointName = "api/getfiles";
            epInfo1.Enabled = true;

            EndPointInformation epInfo2 = new EndPointInformation();
            epInfo2.Server = "server1";
            epInfo2.EndPointName = "api/insertfiles";
            epInfo2.Enabled = false;

            expectedOutput.Add(epInfo1);
            expectedOutput.Add(epInfo2);

            List<EndPointInformation> actualOutput = reader.ReadServersEndPointsInformation();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);
        }



        [TestMethod]
        public void TestReadServersEndPointsInformationForJson()
        {
            var _BootStrap = new Bootstrap();
            var service = _BootStrap.GetService();
            var reader = service.GetReader(@"\\ad.ing.net\wps\BE\D\UD\002001\BQ88WKd\Home\My Documents\Visual Studio 2013\Projects\TestMEFAssignment\TestMEFAssignment\temp", "json");


            List<EndPointInformation> expectedOutput = new List<EndPointInformation>();

            EndPointInformation epInfo1 = new EndPointInformation();
            epInfo1.Server = "server1";
            epInfo1.EndPointName = "api/getfiles";
            epInfo1.Enabled = true;

            EndPointInformation epInfo2 = new EndPointInformation();
            epInfo2.Server = "server1";
            epInfo2.EndPointName = "api/insertfiles";
            epInfo2.Enabled = false;

            expectedOutput.Add(epInfo1);
            expectedOutput.Add(epInfo2);

            List<EndPointInformation> actualOutput = reader.ReadServersEndPointsInformation();
            CollectionAssert.AreEqual(expectedOutput, actualOutput);
        }

    }
}

